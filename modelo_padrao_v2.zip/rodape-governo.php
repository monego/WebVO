
    
	<input type="checkbox" name="cont" id="contrasteRodape" checked="checked" class="none" />
    <label for="contrasteRodape" class="contraste none">ALTO CONTRASTE</label>                
    <a class="contraste none" id="contraste-link-rodape" title="Altere o Contraste">Alto Contraste</a>
    
<div class="rodope-logo-governo" >    
	<div class="conteudo-rodape">
    	<ul>
	    	<li><a href="http://www.acessoainformacao.gov.br/" title="Acesso à Informação" target="_blank"><img src="/img/acesso-a-infornacao.png" alt="Acesso à Informação"></a></li>
	    	<li><a href="http://www.brasil.gov.br/" title="Portal Brasil" target="_blank"><img src="/img/brasil.png" alt="Portal Brasil"></a></li>
    	</ul>
        <div class="clear"><!-- --></div>
  	</div>
</div>

<div class="assina-inpe" >
	<div class="conteudo-rodape">2017 © INPE - Instituto Nacional de Pesquisas Espaciais <span class="right">Desenvolvido por <a href="/ti/" title="Acesse COCTI/INPE" />COCTI/INPE</a></span></div>
</div>