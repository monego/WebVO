

<!--ORIGINAL
- quando a barra do governo sofrer alterações, deve-se entrar através de um navegador no link  abaixo (//barra.brasil.gov.br/barra.js) e copiar o código que aparece para o arquivo /include/barra_governo.js
-->

<div id="barra-brasil"> 
	<ul id="menu-barra-temp">
		<li><a href="http://brasil.gov.br">Portal do Governo Brasileiro</a></li> 
		<li><a href="http://epwg.governoeletronico.gov.br/barra/atualize.html">Atualize sua Barra de Governo</a></li>
	</ul>
</div>